/*************************************************************************/
/*                                                                       */
/* Licensed Materials - Property of IBM                                  */
/*                                                                       */
/*                                                                       */
/* (C) Copyright IBM Corp. 2011                                          */
/* All Rights Reserved                                                   */
/*                                                                       */
/* US Government Users Restricted Rights - Use, duplication or           */
/* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.     */
/*                                                                       */
/*************************************************************************

============================================================================
OVERVIEW
============================================================================


   These two samples, ocr_events and ocr_subbuffers, are intended to
   demonstrate some of the capabilities of IBM OpenCL Common Runtime
   (OCR).


   NOTE:
   =====
   These samples are intended as educational demonstrations of
   capability, and are designed to heavily prefer simplicity and
   clarity over execution speed.


   The ocr_events Application:
   ===========================

   The ocr_events application is a variation of the classic "Hello,
   World!" program, and demonstrates the ability of OCR to create
   events and event dependencies between implementations, including
   implementations provided by different vendors.

   The application performs the following steps:

   (1)  Initializes the OCR platform and sets up the devices.

   (2)  Displays the OpenCL platform used for execution, the devices
        it has access to, and the name and vendor reported by each
        device.  If the OpenCL platform does not appear to be the IBM
        OpenCL Common Runtime, a warning message is displayed.

   (3)  Creates an 80x24 matrix of characters, and populates it with
        tildes ('~').

   (4)  Inserts the ASCII string: "## Hello from the host! ##" into
        the matrix at a random point.

   (5)  Prints the "STARTING MATRIX" to standard output.

   (6)  Enqueues an execution the "append_hello" kernel as an OpenCL
        task onto the command queue of each device present under the
        host, with each task dependent on the completion of the
        previous task.

   (7)  Each device executes the "append_hello" kernel, which:

        - Searches the contents of the matrix linearly to determine
          the end of the "text".

        - Inserts the ASCII string " ## Hello from device: <number>, a
          <device_name> from <device_vendor>! ##" after the position
          determined to be the end of the "text".

   (8)  Enqueues a "map buffer" command, dependent on the completion
        of the last "hello_append" kernel task, demonstrating both the
        cross-implementation event and event routing capabilities of
        the OCR.

   (9)  Prints the "APPENDED MATRIX" to standard output.

   (10) Cleans up, releases resources, and exits


   The ocr_subbuffers Application:
   ===============================

   The ocr_subbuffers application performs an extremely simple
   addition of two arrays of floating point values, and demonstrates
   the ability of OCR to transparently sub-divide, coalesce, and
   manage memory between implementations.

   The application performs the following steps:

   (1)  Parses any command line options.  If any command line options
        are present, they will either be used to set the number of
        elements to add, or to instruct the application to display a
        usage message and exit cleanly.

   (2)  Creates a workload consisting of two equal-length arrays of
        random single-precision floating point values between 0.0 and
        1.0, and a single output array.

   (3)  Initializes the OCR platform and sets up the devices.

   (4)  Displays the OpenCL platform used for execution, the devices
        it has access to, and the name and vendor reported by each
        device.  If the OpenCL platform does not appear to be the IBM
        OpenCL Common Runtime, a warning message is displayed.

   (5)  Determines and displays the minimum base memory address
        alignment value common across all the devices in the instance,
        and creates a single instance-wide buffer for output.

   (6)  Divides the workload up into ranges as evenly as is possible
        while preserving base memory address alignment requirements.
        Each device is allocated two input buffers, and a
        device-specific sub-buffer for output which is a child of the
        shared instance-wide buffer.

   (7)  Displays the number of elements assigned to each device.

   (8)  Enqueues a group of parallel NDRange executions, one execution
        per device, and generates an event for each enqueue.

   (9)  Each device executes the "add_buffers" kernel over the NDRange
        assigned to it, which:

        - Adds the values of the two input buffers together.

        - Places the output into the device's output sub-buffer.

   (10) Issues a blocking read of the _instance-wide_ output buffer,
        dependent on the completion of all the enqueue events,
        demonstrating the ability to of OCR to transparently share
        memory between devices.

   (11) Displays a message indicating completion of execution.

   (12) Cleans up, releases resources, and exits.


============================================================================
PREREQUISITES
============================================================================

   Building these samples require:

     (1) Installation of:

         - IBM OpenCL Common Runtime, version 0.1
         - At least one OpenCL v1.1 implementation with development
           headers

     (2) The file ocr_samples.mk must be edited so the variable
         CL_INCLUDE_DIR is set to the location of the OpenCL v1.1
         development headers

   Running these samples require:

     - IBM OpenCL Common Runtime, version 0.1
     - One or more implementations of OpenCL supported by OCR
        

============================================================================
HOW TO BUILD  
============================================================================

   To build 32-bit applications, 
   cd to the x86 directory and type "make".
   
   To build 64-bit applications, 
   cd to the x86_64 directory and type "make".

============================================================================
HOW TO RUN    
============================================================================


   IMPORTANT:
   ----------

     The location of the IBM OpenCL Common Runtime environment
     must be made available to the application during execution by
     setting the LD_LIBRARY_PATH environment variable.

   
   Running the 32-bit Applications:
   --------------------------------
   Change directories to the x86 directory and invoke the desired
   application with the proper LD_LIBRARY PATH, and any command line
   options (if applicable).  

   Examples:
 
     To run the 32-bit ocr_events application:

       $ cd x86
       $ LD_LIBRARY_PATH=/opt/ibm/OpenCLCommonRuntime/lib ./ocr_events

     To run the 32-bit ocr_subbuffers application:

       $ cd x86
       $ LD_LIBRARY_PATH=/opt/ibm/OpenCLCommonRuntime/lib ./ocr_subbuffers
   
   Running the 64-bit Applications:
   --------------------------------
   Change directories to the x86_64 directory and invoke the desired
   application with the proper LD_LIBRARY PATH, and any command line
   options (if applicable).

   Examples:

     To run the 64-bit ocr_events application:

       $ cd x86_64
       $ LD_LIBRARY_PATH=/opt/ibm/OpenCLCommonRuntime/lib64 ./ocr_events

     To run the 64-bit ocr_subbuffers application:

       $ cd x86_64
       $ LD_LIBRARY_PATH=/opt/ibm/OpenCLCommonRuntime/lib64 ./ocr_subbuffers


============================================================================
COMMAND LINE SYNTAX
============================================================================

  The ocr_events Application:
  ---------------------------
  No command line options.


  The ocr_subbuffers Application:
  ------------------------------- 
  ocr_subbuffers [--help|--usage] | [ELEMENTS]

  Examples:
    ocr_subbuffers          # execute with default number of elements (32768)
    ocr_subbuffers 8192     # execute with 8192 elements
    ocr_subbuffers --usage  # display brief usage message

  Options:
    ELEMENTS           use ELEMENTS work elements (limit: 4294967295)
    -?, --usage        display usage summary
        --help         display this help message

============================================================================
END OF TEXT
============================================================================
