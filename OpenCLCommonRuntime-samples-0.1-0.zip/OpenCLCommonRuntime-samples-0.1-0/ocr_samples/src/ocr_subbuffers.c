/*************************************************************************/
/*                                                                       */
/* Licensed Materials - Property of IBM                                  */
/*                                                                       */
/*                                                                       */
/*                                                                       */
/* (C) Copyright IBM Corp. 2011                                          */
/* All Rights Reserved                                                   */
/*                                                                       */
/* US Government Users Restricted Rights - Use, duplication or           */
/* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.     */
/*                                                                       */
/*************************************************************************/
/* PROLOG END TAG zYx                                                    */

#define _GNU_SOURCE
#include <stdio.h>
#include <limits.h>
#include <stdlib.h>
#include <time.h>
#include <sys/types.h>
#include <unistd.h>

#include <CL/opencl.h>

#include "utils.h"
#include "instance.h"
#include "device.h"

#define KERNEL_FILE "ocr_subbuffers_kernel.cl"
#define KERNEL_NAME "add_buffers"

#define DEFAULT_WORK_ELEMENTS 32768


// Structure encapsulating the workload used by the example
struct sb_workload_st {

  // Number of element in the arrays
  cl_uint num_elements;

  // Input arrays
  float* input_a;
  float* input_b;

  // Output array
  float* output;

};


//
//  Private function prototypes
//

// Help and usage
static void help();
static void usage();

// Setup and execution
static void initialize(int argc, char** argv, cl_uint* work_elements);
static void add_buffers(struct instance_st* instance, 
                        struct sb_workload_st* workload);

// Workload management
static struct sb_workload_st* sb_workload_create(cl_uint num_elements);
static void sb_workload_release(struct sb_workload_st* workload);




int main(int argc, char** argv)
{
  struct instance_st* instance;
  struct sb_workload_st* workload;
  cl_uint work_elements;


  // Parse the command line and set the number of work elements
  initialize(argc,argv,&work_elements);
  


  // Seed the libc PRNG, using time (in seconds) + the process ID to somewhat
  // dependably get a distinct random value even when invoked within 
  // sub-second intervals
  srand(time(NULL) + getpid());

  
  // Create the workload
  workload = sb_workload_create(work_elements);

  // Create an instance of OpenCL, and populate it will all devices found
  instance = instance_create();

  // Create the program from source
  instance_create_program(instance,KERNEL_FILE);

  // Load the kernels
  instance_create_kernel(instance,KERNEL_NAME);

  // Perform the work
  add_buffers(instance,workload);

  // Release the resources held by the instance
  instance_release(instance);

  // Release the workload
  sb_workload_release(workload);

  return 0;
}



static void usage()
{
  printf("Usage: %s [--help|--usage] | [ELEMENTS]\n",
         program_invocation_short_name);
}



static void help()
{
  usage();
  printf("\n");
  printf("  Demonstrate OCR use of sub-buffers.\n");
  printf("\n");
  printf("Examples:\n");
  printf("  %s          # execute with default number of elements (%u)\n",
         program_invocation_short_name, 
         DEFAULT_WORK_ELEMENTS);
  printf("  %s 8192     # execute with 8192 elements\n", 
         program_invocation_short_name);
  printf("  %s --usage  # display brief usage message\n", 
         program_invocation_short_name);
  printf("\n");
  printf("Options:\n");
  printf("  ELEMENTS           use ELEMENTS work elements (limit: %u)\n",
         UINT_MAX);
  printf("  -?, --usage        display usage summary\n");
  printf("      --help         display this help message\n");
  printf("\n"); 
}



static void initialize(int argc, char** argv, cl_uint* work_elements)
{  

  // Set work elements to the default
  *work_elements = DEFAULT_WORK_ELEMENTS;

  //
  // Parse the command line arguments (if any)
  //
  if(argc == 2) {

    //
    // Only one argument, determine what it is and handle it
    //

    // Check for help option
    if(strcmp(argv[1],"--help") == 0) {
      help();
      exit(EXIT_SUCCESS);
    }

    // Check for usage options
    if((strcmp(argv[1],"-?") == 0) || (strcmp(argv[1],"--usage") == 0)) {
      usage();
      exit(EXIT_SUCCESS);
    }
    
    // Otherwise, the argument should be a size
    unsigned long val;
    char* endptr;

    // Clear errno, and convert to unsigned long
    errno = 0;
    val = strtoul(argv[1],&endptr,10);

    // Check for errors in conversion
    if((errno != 0) || (endptr == argv[1]) || (*endptr != '\0')) {
      fprintf(stderr,"%s: unknown or invalid options.\n",
              program_invocation_short_name);
      fprintf(stderr,"Try `%s --help' or `%s --usage' for more information.\n",
              program_invocation_short_name,
              program_invocation_short_name);
      exit(EXIT_FAILURE);
    }

    if(val > UINT_MAX) {
      fprintf(stderr,"%s: number of elements too large (limit: %u).\n",
              program_invocation_short_name,
              UINT_MAX);
      exit(EXIT_FAILURE);
    }
    
    *work_elements = val;
    
  }
  else if(argc > 2) {
    fprintf(stderr,"%s: unknown or invalid options.\n",
            program_invocation_short_name);
    fprintf(stderr,"Try `%s --help' or `%s --usage' for more information.\n",
            program_invocation_short_name,
            program_invocation_short_name);
    exit(EXIT_FAILURE);
  }  

}




static void add_buffers(struct instance_st* instance, 
                        struct sb_workload_st* workload)
{
  cl_uint i;
  cl_int clrc;

  // Pointers to per-device input buffers
  cl_mem* input_a_bufs; 
  cl_mem* input_b_bufs;

  // Single "parent" output buffer,and pointers to the per-device
  // sub-buffers within it
  cl_mem output_buf;
  cl_mem* output_sub_bufs;

  // Array of events for the device NDRange enqueues
  // Each enqueue generates an event, and all these events must complete 
  // before the final state can be read safely.
  cl_event* events = NULL;
  ASSERT_ALLOC(events = (cl_event*)
               malloc(sizeof(cl_event)*instance->numDevices));

  // Retrieve the minimum alignment necessary to align all device
  // sub-buffers equally
  cl_uint min_align = instance_base_addr_align(instance);
  printf("Base address alignment: %u bytes\n",min_align);

  // Tally of how much work is left to distribute
  cl_uint elements_left = workload->num_elements;

  // Offset into the buffers
  cl_uint offset = 0;

  // Tally of how many enqueues have been performed (It is possible to
  // have fewer enqueues than devices when the total amount of work is
  // exceedingly small)
  cl_uint num_enqueues = 0;  
 
  // Retrieve the kernel from the instance
  cl_kernel kernel = instance->kernel;
  if(kernel == NULL) {
    DISPLAY_ERROR_AND_EXIT("Unable to find kernel \"%s\"",KERNEL_NAME);
  }

  // Allocate cl_mem objects for the input buffers and output
  // sub-buffers
  ASSERT_ALLOC(input_a_bufs = 
               (cl_mem*)calloc(instance->numDevices,sizeof(cl_mem)));
  ASSERT_ALLOC(input_b_bufs = 
               (cl_mem*)calloc(instance->numDevices,sizeof(cl_mem)));
  ASSERT_ALLOC(output_sub_bufs = 
               (cl_mem*)calloc(instance->numDevices,sizeof(cl_mem)));


  // Create the single "parent" output buffer
  output_buf = clCreateBuffer(instance->context,
                              (CL_MEM_WRITE_ONLY|CL_MEM_ALLOC_HOST_PTR),
                              workload->num_elements * sizeof(float),
                              NULL,
                              &clrc);
  ASSERT_CL_SUCCESS(clrc,"Failed to create output buffer");


  //
  // Iterate over all devices in the instance, and assign them work
  //
  for(i = 0; i < instance->numDevices; i++) {


 
    // The amount of work depends (in part) on if this device is the
    // last device in the instance
    cl_uint dev_elements;
    if((i + 1) != instance->numDevices) {
      
      //
      // Not the last device 
      //

      // Determine the "optimum" number of elements to assign
      dev_elements = elements_left / (instance->numDevices - i);
      
      // If the number of elements is greater than the minimum
      // alignment, ensure it is a multiple of min_align by rounding
      // down
      if((dev_elements * sizeof(float)) > min_align) {
        dev_elements = (((dev_elements * sizeof(float)) / min_align) 
                        * min_align) / sizeof(float);
      }
      else {
        // Can't round down because the result would be zero, so,
        // round up
        dev_elements = (min_align / sizeof(float));

        // And finally check that the number of elements doesn't
        // exceed the amount of work remaining
        if(dev_elements > elements_left) {
          dev_elements = elements_left;
        }
      }
    }
    else {

      //
      // Last device
      // 
      // Assign all remaining work
      dev_elements = elements_left;
    }


    printf("Device %u buffer size: %u elements (%zd bytes)\n",
           i,
           dev_elements,
           dev_elements * sizeof(float));


    // Only perform and enqueue if the device ended up with work.
    // (Which should happen unless an extremely small total size is
    // specified)
    if(dev_elements > 0 ) {

      // Create a device-specific input buffer for input_a
      input_a_bufs[i] = clCreateBuffer(instance->context,
                                       (CL_MEM_READ_ONLY|CL_MEM_COPY_HOST_PTR),
                                       dev_elements * sizeof(float),
                                       &workload->input_a[offset],
                                       &clrc);
      ASSERT_CL_SUCCESS(clrc,
                        "Failed to create input_a buffer for device %u",i);
      
      // Create a device-specific input buffer for input_b
      input_b_bufs[i] = clCreateBuffer(instance->context,
                                       (CL_MEM_READ_ONLY|CL_MEM_COPY_HOST_PTR),
                                       dev_elements * sizeof(float),
                                       &workload->input_b[offset],
                                       &clrc);
      ASSERT_CL_SUCCESS(clrc,
                        "Failed to create input_b buffer for device %u",i);
      
      // Define the sub-buffer region for the device's output
      // sub-buffer
      cl_buffer_region region;
      region.origin = offset * sizeof(float);
      region.size = dev_elements * sizeof(float);
      
      // Create the device output sub-buffer
      output_sub_bufs[i] = clCreateSubBuffer(output_buf,
                                             CL_MEM_WRITE_ONLY,
                                             CL_BUFFER_CREATE_TYPE_REGION,
                                             &region,
                                             &clrc);
      ASSERT_CL_SUCCESS(clrc,
                        "Failed to create output sub-buffer for device %u",i);
      

      //
      // Set the workgroup sizes, in this case we are going to assign
      // each addition operation its own local workgroup.
      // Clearly, this is *highly* inefficient, but it reduces the
      // number of boundary conditions and workgroup size multiple
      // constraints which need to be accounted for.
      //
      cl_uint work_dim = 1;
      size_t global_work_size = dev_elements;
      size_t local_work_size = 1;
      
      // Set the kernel arguments for the device:
      //   arg0:  cl_mem object containing device's input_a
      //   arg1:  cl_mem object containing device's input_b
      //   arg2:  cl_mem object containing the device's sub-buffer
      //   arg3:  unsigned int indicating the size of the buffers
      ASSERT_CL(clSetKernelArg(kernel,0,sizeof(cl_mem),&input_a_bufs[i]));
      ASSERT_CL(clSetKernelArg(kernel,1,sizeof(cl_mem),&input_b_bufs[i]));
      ASSERT_CL(clSetKernelArg(kernel,2,sizeof(cl_mem),&output_sub_bufs[i]));
      ASSERT_CL(clSetKernelArg(kernel,3,sizeof(cl_uint),&dev_elements));
   
      // Enqueue the range onto the device, and generate an event
      ASSERT_CL(clEnqueueNDRangeKernel(instance->devices[i]->cmd_queue,
                                       kernel,
                                       work_dim,
                                       NULL,
                                       &global_work_size,
                                       &local_work_size,
                                       0,
                                       NULL,
                                       &events[i]));

      // Increment the number of total enqueues
      num_enqueues++;
    } 
      
    // Subtract the work assigned from the work remaining
    elements_left -= dev_elements;

    // Increment the offset but the work assigned
    offset += dev_elements;
    
  }


  //
  // Enqueue a blocking read of the global buffer 
  //
  // Note:
  //   - As always, the choice of command queue does not matter
  //   - This is a blocking read, so we don't need to wait for it
  //   - The read is dependent on *all* the events generated by the NDRange
  //     enqueues completing before it executes
  //
  ASSERT_CL(clEnqueueReadBuffer(instance->devices[0]->cmd_queue,
                                output_buf,
                                CL_TRUE,
                                0,
                                workload->num_elements * sizeof(float),
                                workload->output,
                                num_enqueues,
                                events,
                                NULL));

  printf("*** Execution complete, %u floats added.\n", workload->num_elements);

  // Release any objects created by enqueues
  for(i = 0; i < num_enqueues; i++) {
    ASSERT_CL(clReleaseEvent(events[i]));
    ASSERT_CL(clReleaseMemObject(output_sub_bufs[i]));
    ASSERT_CL(clReleaseMemObject(input_a_bufs[i]));
    ASSERT_CL(clReleaseMemObject(input_b_bufs[i]));
  }
  
  // Release the list of events
  free(events);

  // Release the "parent" output buffer
  ASSERT_CL(clReleaseMemObject(output_buf));

  // Release the lists of input pointers
  free(input_b_bufs);
  free(input_a_bufs);

 
}



static struct sb_workload_st* sb_workload_create(cl_uint num_elements) 
{
  struct sb_workload_st* sb_workload;

  ASSERT_ALLOC(sb_workload = 
               (struct sb_workload_st*)malloc(sizeof(struct sb_workload_st)));
  ASSERT_ALLOC(sb_workload->input_a = 
               (float*)malloc(sizeof(float)*num_elements));
  ASSERT_ALLOC(sb_workload->input_b = 
               (float*)malloc(sizeof(float)*num_elements));
  ASSERT_ALLOC(sb_workload->output = 
               (float*)calloc(1,sizeof(float)*num_elements));

  sb_workload->num_elements = num_elements;

  // File the workload inputs with values between 0.0 and 1.0f
  cl_uint i;
  for(i = 0; i < num_elements; i++) {
    sb_workload->input_a[i] = ((float)rand()/RAND_MAX);
    sb_workload->input_b[i] = ((float)rand()/RAND_MAX);
  }
  

  return sb_workload;
}



static void sb_workload_release(struct sb_workload_st* workload)
{
  if(workload) {
    if(workload->output) {
      free(workload->output);
    }
    if(workload->input_b) {
      free(workload->input_b);
    }
    if(workload->input_a) {
      free(workload->input_a);
    }
    free(workload);
  }
  
}
