/*************************************************************************/
/*                                                                       */
/* Licensed Materials - Property of IBM                                  */
/*                                                                       */
/*                                                                       */
/*                                                                       */
/* (C) Copyright IBM Corp. 2011                                          */
/* All Rights Reserved                                                   */
/*                                                                       */
/* US Government Users Restricted Rights - Use, duplication or           */
/* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.     */
/*                                                                       */
/*************************************************************************/
/* PROLOG END TAG zYx                                                    */

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/types.h>
#include <unistd.h>

#include <CL/opencl.h>

#include "utils.h"
#include "instance.h"
#include "device.h"

#define KERNEL_FILE "ocr_events_kernel.cl"
#define KERNEL_NAME "append_hello"


// Structure encapsulating the workload used by the example
struct ah_workload_st {

  // Number of rows and columns in the global character matrix
  int rows;
  int cols;

  // Global character matrix
  char* data;
  size_t data_len;

  // Memory buffer containing the global character matrix 
  cl_mem buffer;  
  int buffer_sz;

};


//
//  Private function prototypes
//

// Execution
static void append_hello(struct instance_st* instance, 
                         struct ah_workload_st* workload);

// Workload management
static struct ah_workload_st* ah_workload_create(cl_context context, int rows, 
                                                 int cols, char* base_str);
static void ah_workload_release(struct ah_workload_st* workload);





int main()
{
  struct instance_st* instance;
  struct ah_workload_st* workload;

  int rows; 
  int cols;

  // Seed the libc PRNG, using time (in seconds) + the process ID to somewhat
  // dependably get a distinct random value even when invoked within 
  // sub-second intervals
  srand(time(NULL) + getpid());

  // Set the number of rows and columns of the workload matrix
  rows = 24;
  cols = 80;

 
  // Create an instance of OpenCL, and populate it will all devices found
  instance = instance_create();

  // Create the program from source
  instance_create_program(instance,KERNEL_FILE);

  // Load the kernels
  instance_create_kernel(instance,KERNEL_NAME);

  // Create a simple workload of a char matrix which is rows x cols
  // and then populate it with a "hello world" string on the host
  // side in a random location
  workload = ah_workload_create(instance->context,
                             rows,
                             cols,
                             "## Hello from the host! ##");

  // Invoke the "hello_append" kernel on each of the devices in the instance
  // in series.  
  //
  // This kernel searches the buffer for the end the text, and then appends
  // a device specific string
  append_hello(instance,workload);


  // Release the resources held by the workload
  ah_workload_release(workload);


  // Release the resources held by the instance
  instance_release(instance);



  return 0;
}




static void append_hello(struct instance_st* instance, 
                         struct ah_workload_st* workload)
{
  cl_uint i;
  cl_int clrc;


  // Array of device "hello" string buffers
  // (Each device needs a buffer containing the string it will insert into 
  // the global buffer)

  cl_mem* device_buffers = NULL;
  ASSERT_ALLOC(device_buffers = (cl_mem*)
               malloc(sizeof(cl_mem)*instance->numDevices));

  // Array of device events
  // (Each device generates an event when its kernel is enqueued, and must 
  // wait for the prior device's kernel to complete before starting)
  cl_event* device_events = NULL;
  ASSERT_ALLOC(device_events = (cl_event*)
               malloc(sizeof(cl_event)*instance->numDevices));

  // A point to the last event generated (i.e. the event which needs to be
  // waited for next)
  cl_event* wait_event = NULL;


  cl_kernel kernel = instance->kernel;
  if(kernel == NULL) {
    DISPLAY_ERROR_AND_EXIT("Unable to find kernel \"%s\"",KERNEL_NAME);
  }
  

  //
  // For each device:
  //
  for(i = 0; i < instance->numDevices; i++) {

    struct device_st* device = instance->devices[i];

    // Generate a text "hello" string for the device in host memory.  
    // (asprintf is similar to sprintf, but it allocates memory for the 
    // destination on the fly)
    char* hello_str;
    int hello_str_sz;
    hello_str_sz = asprintf(&hello_str,
                            "  ## Hello from device: %u, a %s from %s! ##",
                            i,
                            device->name,
                            device->vendor);


    // Create a cl_mem object to pass the string in, and populate it
    device_buffers[i] =clCreateBuffer(instance->context,
                                      (CL_MEM_READ_ONLY|CL_MEM_COPY_HOST_PTR),
                                      hello_str_sz, 
                                      hello_str,
                                      &clrc);
    ASSERT_CL_SUCCESS(clrc,
                      "Failed to create deviceStr buffer for %s",
                      device->name);


    // Free the host's copy of the string, since it is no longer needed 
    // because it has been copied during the clCreateBuffer call.
    free(hello_str);


    //
    // Set the kernel arguments for the device:
    //
    //   arg0:  cl_mem object containing the device's "hello" string
    //   arg1:  length of the "hello" string
    //   arg2:  cl_mem object containing the "global" character matrix
    //   arg3:  length of the "global" character matrix
    //
    ASSERT_CL(clSetKernelArg(kernel,
                             0,
                             sizeof(cl_mem),
                             &device_buffers[i]));
    ASSERT_CL(clSetKernelArg(kernel,
                             1,
                             sizeof(hello_str_sz),
                             &hello_str_sz));
    ASSERT_CL(clSetKernelArg(kernel,
                             2,
                             sizeof(cl_mem),
                             &workload->buffer));
    ASSERT_CL(clSetKernelArg(kernel,
                             3,
                             sizeof(workload->buffer_sz),
                             &workload->buffer_sz));


    //
    // Determine if this device needs to wait on a previous device's task 
    // before executing
    //
    // Note:
    //
    //   - The events generated by the tasks are chained together in 
    //     sequence, so waiting of the last event generated implicitly 
    //     waits for all other prior events as well.
    //
    cl_uint num_wait_events;
    if(wait_event == NULL) { 
      // No previous event; nothing to wait for
      num_wait_events = 0;
    }
    else {
      // A previous event, so wait for it
      num_wait_events = 1;
    }

    // Enqueue the task, and generate a new event for it
    ASSERT_CL(clEnqueueTask(device->cmd_queue,
                            kernel,
                            num_wait_events,
                            wait_event,
                            &device_events[i]));
    
    // Set the "previous" event to the event just generated
    wait_event = &device_events[i];
  }


  //
  // Read out the final result by mapping the "global" buffer
  //
  // Note:
  //
  //   - The map operation is dependent on the last task enqueued
  //
  //   - The map is a blocking map, and therefore we implicitly wait for it
  //
  //   - The device command queue which the request is placed into does not 
  //     matter, any queue within the context will work.  While technically 
  //     opaque, it is reasonable to assume the buffer likely resides within 
  //     the memory space of devices[instance->numDevices - 1]; however, the
  //     underlying framework is smart enough to know this as well, and 
  //     efficiently routes the request to the proper queue.  In other words, 
  //     attempting to optimize by guessing where memory "should" be does not
  //     improve performance in any meaningful way, and goes against the
  //     overall OpenCL programming model.
  //  
  char* mapped_data;
  mapped_data = clEnqueueMapBuffer(instance->devices[0]->cmd_queue,
                                   workload->buffer,
                                   CL_TRUE,
                                   CL_MAP_READ,
                                   0,
                                   workload->buffer_sz,
                                   1,
                                   wait_event,
                                   NULL,
                                   &clrc);
  ASSERT_CL_SUCCESS(clrc,"Failed to map buffer");


  // Display the intermediate result 
  printf("APPENDED MATRIX:\n");
  for(i = 0; i < workload->rows; i++) {
    printf("%.*s\n",workload->cols,&mapped_data[i*workload->cols]);
  }
  printf("\n");

  //
  // Unmap the global buffer (but keep it around for the next kernel)
  //
  // Note:
  //
  //   - Once again, the choice of command queue does not matter
  //
  ASSERT_CL(clEnqueueUnmapMemObject(instance->devices[0]->cmd_queue,
                                    workload->buffer,
                                    mapped_data,
                                    0,
                                    NULL,
                                    NULL));

  //
  // Wait for the unmapping to finish
  //
  // Note:
  //
  //   - Obviously, which the choice of queue doesn't matter on the enqueue, 
  //     the same queue must be waited on (unless you generate an event and
  //     wait for that instead)
  //
  ASSERT_CL(clFinish(instance->devices[0]->cmd_queue));


  // Release the device events and "hello" buffers
  for(i = 0; i < instance->numDevices; i++) {
    ASSERT_CL(clReleaseEvent(device_events[i]));
    ASSERT_CL(clReleaseMemObject(device_buffers[i]));
  }
  free(device_events);
  free(device_buffers);


}


static struct ah_workload_st* ah_workload_create(cl_context context, int rows, 
                                                 int cols, char* base_str)
{
  struct ah_workload_st* workload;
  
  // Allocate the workload structure
  ASSERT_ALLOC(workload = 
	       (struct ah_workload_st*)malloc(sizeof(struct ah_workload_st)));

  // Set the basic properties
  workload->rows = rows;
  workload->cols = cols;
  workload->data_len = (rows * cols) * sizeof(char);

  // Allocate the host's copy of the character matrix, and set it to all '~'
  ASSERT_ALLOC(workload->data = (char*)malloc(workload->data_len));
  memset(workload->data,'~',workload->data_len);

  // Pick a random point within the matrix to insert the host's base string
  int insert_point = (int)((float)(rows*cols)*((float)rand()/(RAND_MAX+1.0)));

  // Determine the length of the base string, and perform the insertion in 
  // a manner which accounts for wrapping around the buffer if needed
  int total_len = strlen(base_str);

  if(insert_point + total_len < workload->data_len) {
    // No wrap needed
    memcpy(workload->data + insert_point,base_str,total_len);
  }
  else {
    // Wrapping required, so compute how much we insert without wrapping
    int unwrapped_len = workload->data_len - insert_point;

    // And insert that
    memcpy(workload->data + insert_point,base_str,unwrapped_len);

    // Then, insert the remainder into the beginning
    memcpy(workload->data, base_str+unwrapped_len,total_len - unwrapped_len);
  }

  // Create the "global" buffer which will be used to pass the character 
  // matrix into devices, and populate it with the contents of the workload
  //
  // Note:
  //   - The buffer needs to be created with CL_MEM_ALLOC_HOST_PTR because we
  //     intend to map this buffer later, and the OpenCL spec does not require
  //     that an implementation provide mappable access to a buffer unless it
  //     is created with CL_MEM_ALLOC_HOST_PTR.  Many implementations will
  //     succeed in the absence of this flag, but including it simplifies the
  //     need to detect and handle implementations which don't when the map 
  //     request is issued.
  //
  //   - Technically, we could free the data pointer at this point, but it
  //     makes more sense to leave it allocated so we can reuse it when we
  //     read back the final results
  int clrc;
  workload->buffer_sz = workload->data_len * sizeof(char);
  workload->buffer = clCreateBuffer(context, 
                                    ( CL_MEM_READ_WRITE | 
				      CL_MEM_ALLOC_HOST_PTR |
				      CL_MEM_COPY_HOST_PTR ),
                                    workload->buffer_sz, 
                                    workload->data,&clrc);
  ASSERT_CL_SUCCESS(clrc,"Failed to create global buffer");

  // Display the starting matrix
  printf("\n");
  printf("STARTING MATRIX:\n");
  int i;
  for(i = 0; i < workload->rows; i++) {
    printf("%.*s\n",workload->cols,&workload->data[i*workload->cols]);
  }
  printf("\n");

  return workload;
}



static void ah_workload_release(struct ah_workload_st* workload)
{
  if(workload) {
    if(workload->data) {
      free(workload->data);
    }
    if(workload->buffer) {
      clReleaseMemObject(workload->buffer);
    }
    free(workload);
  }
}
