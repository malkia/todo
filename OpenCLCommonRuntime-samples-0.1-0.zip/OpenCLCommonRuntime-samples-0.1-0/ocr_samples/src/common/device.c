/*************************************************************************/
/*                                                                       */
/* Licensed Materials - Property of IBM                                  */
/*                                                                       */
/*                                                                       */
/*                                                                       */
/* (C) Copyright IBM Corp. 2011                                          */
/* All Rights Reserved                                                   */
/*                                                                       */
/* US Government Users Restricted Rights - Use, duplication or           */
/* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.     */
/*                                                                       */
/*************************************************************************/
/* PROLOG END TAG zYx                                                    */


#define _GNU_SOURCE

#include <stdlib.h>

#include "utils.h"

#include "device.h"


struct device_st* device_create(cl_context context, cl_device_id id)
{
  size_t len;
  cl_int clrc;

  struct device_st* device;

  // Allocate the device structure
  ASSERT_ALLOC(device = (struct device_st*)malloc(sizeof(struct device_st)));

  // Set the OpenCL device id
  device->id = id;

  // Query the device's name, allocate space for it, and then populate 
  ASSERT_CL(clGetDeviceInfo(device->id, CL_DEVICE_NAME, 0, NULL, &len));
  ASSERT_ALLOC(device->name = (char*)malloc(len));
  ASSERT_CL(clGetDeviceInfo(device->id, 
                            CL_DEVICE_NAME, 
                            len, 
                            device->name, 
                            NULL));

  // Query the device's vendor, allocate space for it, and then populate 
  ASSERT_CL(clGetDeviceInfo(device->id, CL_DEVICE_VENDOR, 0, NULL, &len));
  ASSERT_ALLOC(device->vendor = (char*)malloc(len));
  ASSERT_CL(clGetDeviceInfo(device->id, 
                            CL_DEVICE_VENDOR, 
                            len, 
                            device->vendor, 
                            NULL));


  // Create the command queue
  //
  // Note:
  //  - The clCreateCommandQueue call is invoked with default properties,
  //    which means all commands to *this device* will execute in order, and 
  //    that much of the ordering imposed later in this example using tasks is
  //    only needed in scenarios where multiple devices are present.
  device->cmd_queue = clCreateCommandQueue(context, device->id, 0, &clrc);
  ASSERT_CL_SUCCESS(clrc,
                    "Failed to create a command queue for %s",
                    device->name);

  return device;
}


void device_release(struct device_st* device)
{
  if(device == NULL) {
    return;
  }

  if(device->cmd_queue != 0) {
    clReleaseCommandQueue(device->cmd_queue);
  }

  free(device->name);
  free(device->vendor);

  free(device);
}


