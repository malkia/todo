/*************************************************************************/
/*                                                                       */
/* Licensed Materials - Property of IBM                                  */
/*                                                                       */
/*                                                                       */
/*                                                                       */
/* (C) Copyright IBM Corp. 2011                                          */
/* All Rights Reserved                                                   */
/*                                                                       */
/* US Government Users Restricted Rights - Use, duplication or           */
/* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.     */
/*                                                                       */
/*************************************************************************/
/* PROLOG END TAG zYx                                                    */


#ifndef _UTILS_H_
#define _UTILS_H_


#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

#include <CL/opencl.h>

//
// UTILITIES TO SIMPLIFY COMMON OPENCL TASKS
//


// Format of the error leader
#define _ERR_FMT "[ERROR] %s:%d %s(...)  "
#define _ERR_ARGS basename((char*)__FILE__), __LINE__, __PRETTY_FUNCTION__    

//
// Internal macro to display error leader and message
//
#define _DISPLAY_ERROR(_errstr, _fmt, _args...)                         \
  fprintf(stderr, _ERR_FMT _fmt ": %s\n", _ERR_ARGS, ## _args, _errstr);


//
// Convert _clrc to string, and display error with message
//
#define DISPLAY_ERROR_CLRC(_clrc, _fmt, _args...)       \
  _DISPLAY_ERROR(clstrerror(_clrc), _fmt, ## _args)


//
// Ensure memory is allocated, or display error and exit
//
#define ASSERT_ALLOC(_statement) {                                      \
    if((_statement) == NULL) {						\
      _DISPLAY_ERROR(strerror(errno), #_statement);                     \
      exit(EXIT_FAILURE);                                               \
    }                                                                   \
  }


// 
// Check that a statement returns CL_SUCCESS, otherwise convert return to
// string, display error, and exit
//
#define ASSERT_CL(_statement) {                                         \
    cl_int _clrc = _statement;                                          \
    if(_clrc != CL_SUCCESS) {						\
      DISPLAY_ERROR_CLRC(_clrc,#_statement);                            \
      exit(EXIT_FAILURE);                                               \
    }                                                                   \
  }


//
// Check an OpenCL return code and verify it is CL_SUCCESS, otherwise, convert
// it to a string, display and error message, and exit
//
#define ASSERT_CL_SUCCESS(_clrc, _fmt, _args...)                        \
  if(_clrc != CL_SUCCESS) {						\
    DISPLAY_ERROR_CLRC(_clrc, _fmt, ## _args);                          \
    exit(EXIT_FAILURE);                                                 \
  }         


//
// Display an error message, and exit
//
#define DISPLAY_ERROR_AND_EXIT(_fmt, _args...)                          \
  _DISPLAY_ERROR("", _fmt, ## _args);                                   \
  exit(EXIT_FAILURE);


//
// Convert current value of errno to string, display an error message, and exit
//
#define DISPLAY_ERRNO_AND_EXIT(_fmt, _args...)                          \
  _DISPLAY_ERROR(strerror(errno), _fmt, ## _args);                      \
  exit(EXIT_FAILURE);


//
// Convert "errcode" to a statically allocated string value
//
const char *clstrerror(cl_int errcode);

#endif
