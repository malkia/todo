/*************************************************************************/
/*                                                                       */
/* Licensed Materials - Property of IBM                                  */
/*                                                                       */
/*                                                                       */
/*                                                                       */
/* (C) Copyright IBM Corp. 2011                                          */
/* All Rights Reserved                                                   */
/*                                                                       */
/* US Government Users Restricted Rights - Use, duplication or           */
/* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.     */
/*                                                                       */
/*************************************************************************/
/* PROLOG END TAG zYx                                                    */


#define _GNU_SOURCE

#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>

#include "utils.h"

#include "instance.h"

//
// Private function prototypes
//
static char *load_text_file(const char *filename);


struct instance_st* instance_create()
{
  cl_int clrc;
  size_t len;
  struct instance_st* instance;

  // Create an instance_st structure
  ASSERT_ALLOC(instance = 
               (struct instance_st*)malloc(sizeof(struct instance_st)));

  // Initialize the instance to have no program
  instance->program = NULL;

  // Initialize the instance to have no kernel
  instance->kernel = NULL;


  // Obtain the default platform
  // (This should be the OCR platform if it is properly installed and 
  // configured)
  ASSERT_CL(clGetPlatformIDs(1, &instance->platform, NULL));

  // Obtain the platform name
  ASSERT_CL(clGetPlatformInfo(instance->platform, 
                              CL_PLATFORM_VENDOR, 
                              0, 
                              NULL, 
                              &len));

  ASSERT_ALLOC(instance->name = (char*)malloc(len));
  ASSERT_CL(clGetPlatformInfo(instance->platform, 
                              CL_PLATFORM_VENDOR, 
                              len, 
                              instance->name, 
                              NULL));

  // This should be "IBM" if the OCR platform is properly installed and 
  // configured
  printf("OpenCL platform: %s\n",instance->name);
  if(strcmp(instance->name,"IBM") != 0) { 
    printf("WARNING: Platform does not appear to be IBM OCR, check LD_LIBRARY_PATH\n");
  }

  
  // Determine how many devices are accessible
  // (Depends on OCR configuration, but may include devices from several 
  // implementations)
  ASSERT_CL(clGetDeviceIDs(instance->platform,
                           CL_DEVICE_TYPE_ALL,
                           0,
                           NULL,
                           &instance->numDevices));
  printf("OpenCL devices : %u\n",instance->numDevices);

  // Allocate a list large enough to hold all the device IDs, and populate it
  ASSERT_ALLOC(instance->deviceIds = (cl_device_id*)
	       malloc(sizeof(cl_device_id) * instance->numDevices));  
  ASSERT_CL(clGetDeviceIDs(instance->platform,
                           CL_DEVICE_TYPE_ALL,
			   instance->numDevices,
                           instance->deviceIds,
                           NULL));
  
  // Create a context requesting all devices
  cl_context_properties cprops[3] = { 
    CL_CONTEXT_PLATFORM, 
    (cl_context_properties) instance->platform, 
    0 };
  instance->context = clCreateContext(cprops,
                                      instance->numDevices,
                                      instance->deviceIds,
                                      NULL,
                                      NULL,
                                      &clrc);
  ASSERT_CL_SUCCESS(clrc, "Failed to create context for selected devices");

  ASSERT_ALLOC(instance->devices = (struct device_st**)
               malloc(sizeof(struct device_st*)*instance->numDevices));

  // For each device, create a device_st structure, and initialize it
  cl_uint i;
  for(i = 0; i < instance->numDevices; i++) {
    instance->devices[i] = device_create(instance->context,
                                         instance->deviceIds[i]);
    printf("Device %u: %s, %s\n",
           i,
           instance->devices[i]->vendor,
           instance->devices[i]->name);
  }

  return instance;
}



void instance_release(struct instance_st* instance)
{
  if(instance == NULL) {
    return;
  }

  cl_uint i;
  for(i = 0; i < instance->numDevices; i++) {
    device_release(instance->devices[i]);
  }
  free(instance->deviceIds);
  free(instance->devices);

  if(instance->kernel != NULL) {
    clReleaseKernel(instance->kernel);
    instance->kernel = NULL;
  }


  clReleaseContext(instance->context);

  free(instance->name);

  free(instance);
}



void instance_create_program(struct instance_st* instance, 
                             const char* src_file)
{
  char* src;
  cl_int clrc;

  // Attempt to load the kernel source.
  // Note:
  //   - if this fails, the underlying function calls exit(...) so we don't 
  //     need to check for success
  src = load_text_file(src_file);
 
  // Create the actual program
  instance->program = clCreateProgramWithSource(instance->context, 
                                                1, 
                                                (const char **) &src, 
                                                NULL, 
                                                &clrc);

  ASSERT_CL_SUCCESS(clrc,"Failed to create program from source");

  // Free the buffer containing the source
  free(src);

  
  // Attempt to build the program
  // Note:
  //   - We build for all devices simultaneously, though building individually 
  //     is also a valid approach
  //   - The "-Werror" build option is passed, which is not required, but does
  //     surface some otherwise subtle bugs when developing more complex 
  //     kernels, and thus is recommended
  clrc = clBuildProgram(instance->program,
                        instance->numDevices,
                        instance->deviceIds,
                        "-Werror",
                        NULL,
                        NULL);

  if(clrc != CL_SUCCESS) {

    DISPLAY_ERROR_CLRC(clrc,"Failed to create program from source");

    // If we failed, we need to iterate over all the builds and find out 
    // which build(s) failed and why
    size_t len;
    cl_uint i;
    for(i = 0; i < instance->numDevices; i++) {

      // First, get the size of the build log
      // (and yes, this can fail as well...)
      if((clrc = clGetProgramBuildInfo(instance->program, 
                                       instance->deviceIds[i], 
                                       CL_PROGRAM_BUILD_LOG, 
                                       0, 
                                       NULL, 
                                       &len)) != CL_SUCCESS) {
        DISPLAY_ERROR_CLRC(clrc, 
                           "Failed to get size of build log for %s",
                           instance->devices[i]->name);
      }
      else {

        // Assuming we were able to determine the size, allocate space for it 
        // and retrieve it
        char* buffer;                  
        ASSERT_ALLOC(buffer = (char*)malloc(len));
        
        clrc = clGetProgramBuildInfo(instance->program, 
                                     instance->deviceIds[i], 
                                     CL_PROGRAM_BUILD_LOG, 
                                     len, 
                                     buffer, 
                                     NULL);
        if(clrc == CL_SUCCESS) {
          // If successful, print it out
          printf("%s\n", buffer);
        }
        else {
          // Otherwise, at least log the device which failed
          DISPLAY_ERROR_CLRC(clrc,
                             "Failed to get build log for device %s",
                             instance->devices[i]->name);
        }

        // Release the buffer memory
        free(buffer);
      }
    }
    
    // Exit (because we are pretty much dead at this point)
    exit(EXIT_FAILURE);
  }

}


void instance_create_kernel(struct instance_st* instance, 
                            const char* kernel_name)
{
  cl_int clrc;

  // Ensure the instance has a program
  if(instance->program == NULL) {
    DISPLAY_ERROR_AND_EXIT("No OpenCL program created");
  }
  
  // Release any existing kernel
  if(instance->kernel != NULL) {
    ASSERT_CL(clReleaseKernel(instance->kernel));
  }

  // Create the kernel
  instance->kernel = clCreateKernel(instance->program,kernel_name,&clrc);
  ASSERT_CL_SUCCESS(clrc,"Failed to create kernel: %s",kernel_name);
  
}





cl_uint instance_base_addr_align(struct instance_st* instance)
{
  //
  // This function returns the smallest value for base memory address
  // alignment which is valid for all devices in the instance.  To so
  // this, a the function computes the least common multiple of base
  // memory address alignments of the the devices.  Performing this
  // calculation is relatively simple, and relies on the following
  // basic principles:
  ///
  // The greatest common divisor (gcd) of two numbers can be
  // determined by using a version of the Euclidean Algorithm, which
  // iteratively tests divisors (via modulo) in sequentially smaller
  // steps until a divisor is located which produces no remainder.
  //
  // gcd(x,y):
  //
  //
  //   while(y != 0) {
  //     int swp = y;
  //     y = x mod y;
  //     x = swp
  //   }
  //
  // The least common multiple of two numbers can be obtained by via
  // the following relationship:
  //
  //   lcm(x,y) = x * ( y / gcd(x,y) ) 
  //
  // The least common multiple (lcm) of a series of numbers can be
  // found by chaining the lcm operation over the series:
  // 
  // For example:
  //
  //   lcm(a,b,c) = lcm(a,lcm(b,c))
  //

  cl_uint i;
  cl_uint min_common_addr_align;
  
  for(i = 0; i < instance->numDevices; i++) {
    
    cl_uint dev_mem_align;
    ASSERT_CL(clGetDeviceInfo(instance->deviceIds[i],
                              CL_DEVICE_MEM_BASE_ADDR_ALIGN,
                              sizeof(cl_uint),
                              &dev_mem_align,
                              NULL));
    
    // OpenCL returns this value in bits, convert to bytes
    dev_mem_align = dev_mem_align / 8;
    
    if(i == 0 ) {
      min_common_addr_align = dev_mem_align;
    }
    else {
      //
      // Euclid's algorithm for GCD
      //
      int gcd = min_common_addr_align;
      int rem = dev_mem_align;
      while(rem != 0) {
        int swp = rem;
        rem = gcd % rem;
        gcd = swp;
      }
      
      // 
      // lcm(x,y) = x * ( y / gcd(x,y) )
      //
      min_common_addr_align =  (min_common_addr_align * (dev_mem_align / gcd));
    }
  }
  
  return  min_common_addr_align;
}



static char *load_text_file(const char *filename)
{
  struct stat statbuf;
  char* contents = NULL;

  if(stat(filename, &statbuf) != 0) {
    DISPLAY_ERRNO_AND_EXIT("Failed to stat %s",filename);
  }

  FILE *fh;
  if((fh = fopen (filename, "r")) == NULL) {
    DISPLAY_ERRNO_AND_EXIT("Failed to open %s",filename);
  }

  ASSERT_ALLOC(contents = (char*)calloc(1,statbuf.st_size));

  size_t bytes_left = statbuf.st_size;
  size_t size_in;
  char* ptr = contents;

  while((size_in = fread(ptr, 1, bytes_left, fh)) != 0) {
    ptr+= size_in;
    bytes_left -= size_in;
  }

  if(ferror(fh)) {
    DISPLAY_ERRNO_AND_EXIT("Error reading %s",filename);
  }

  fclose(fh);

  return contents;
}
