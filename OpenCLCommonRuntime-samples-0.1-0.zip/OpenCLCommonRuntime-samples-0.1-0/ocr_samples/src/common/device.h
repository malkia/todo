/*************************************************************************/
/*                                                                       */
/* Licensed Materials - Property of IBM                                  */
/*                                                                       */
/*                                                                       */
/*                                                                       */
/* (C) Copyright IBM Corp. 2011                                          */
/* All Rights Reserved                                                   */
/*                                                                       */
/* US Government Users Restricted Rights - Use, duplication or           */
/* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.     */
/*                                                                       */
/*************************************************************************/
/* PROLOG END TAG zYx                                                    */


#ifndef _DEVICE_H_
#define _DEVICE_H_

#include <CL/opencl.h>

// Structure encapsulating information and attributes of an OpenCL device
struct device_st {

  // The native OpenCL device id
  cl_device_id id;  

  // Name and vendor of the device, as reported by the underlying
  // implementation
  char* name;       
  char* vendor;

  // Command queue associated with this device
  cl_command_queue cmd_queue;

};


struct device_st* device_create(cl_context context, cl_device_id id);
void device_release(struct device_st* device);

#endif


