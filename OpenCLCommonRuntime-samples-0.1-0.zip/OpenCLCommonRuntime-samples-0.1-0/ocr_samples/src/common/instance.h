/*************************************************************************/
/*                                                                       */
/* Licensed Materials - Property of IBM                                  */
/*                                                                       */
/*                                                                       */
/*                                                                       */
/* (C) Copyright IBM Corp. 2011                                          */
/* All Rights Reserved                                                   */
/*                                                                       */
/* US Government Users Restricted Rights - Use, duplication or           */
/* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.     */
/*                                                                       */
/*************************************************************************/
/* PROLOG END TAG zYx                                                    */


#ifndef _INSTANCE_H_
#define _INSTANCE_H_

#include <CL/opencl.h>

#include "device.h"

// Structure encapsulating information about the overall OpenCL instance and 
// context
struct instance_st {

  cl_platform_id platform;  // Native OpenCL platform id
  char* name;  // Name of the platform (as reported by underlying impl)
  cl_context context;  // Native OpenCL context
  cl_uint numDevices;  // Number of devices we own within the context
  cl_program program;  // Handle to the OpenCL program containing our kernels
  cl_device_id* deviceIds;  // Array of native OpenCL device ids we own 
                            // within the context

  struct device_st** devices;  // Array of pointers to device_st structures, 
                               // each of which represents a device

  cl_kernel kernel; // Pointer to the kernel used by this instance  
};

struct instance_st* instance_create();

void instance_release(struct instance_st* instance);

void instance_create_program(struct instance_st* instance, 
                             const char* src_file);

void instance_create_kernel(struct instance_st* instance, 
                            const char* kernel_name);

cl_uint instance_base_addr_align(struct instance_st* instance);

#endif
